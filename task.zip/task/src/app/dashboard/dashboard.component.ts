import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IMonth, IYear, IPaymentModel } from '../cardInterface';
import {  getValidationConfigFromCardNo } from '../cardmodels';
import { luhnValidator } from '../luhn.validators';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  paymentForm : FormGroup
  newValue: string;
  monthlist: IMonth[] = [];
  month:IMonth = <IMonth>{}; 

  year:IYear = <IYear>{};  
  years: IYear[] = [];

  paymentmodel:IPaymentModel = <IPaymentModel>{}

  isSubmitted:boolean = false;
  cardValidate:boolean = false;
  cardDetailsValidate:boolean = false;
  cardType:string = "";
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.IntializePaymentForm();
    this.GetMonths();
   this.GetYears();
  }
  logOut(){
     this.IntializePaymentForm();
     this.GetMonths();
    this.GetYears();
  }
  GetMonths() {
    for (let i = 1; i <= 12; i++) {
      this.month = <IMonth>{};
      if(i.toString().length == 1)
      {
        this.month.text = "0"+i.toString();
        this.month.value = "0"+i.toString();
      }
      else
      {
        this.month.text = i.toString();
        this.month.value = i.toString();
      }
      
      this.monthlist.push(this.month);
    }
  }
 
  GetYears() {
    let year = new Date().getFullYear();
    for (let i = year; i <= year + 20; i++) {
      this.year = <IYear>{};
      this.year.text = i.toString();
      this.year.value = i.toString();
      this.years.push(this.year);
    }
  }

  cardMaskFunction(rawValue: string): Array<RegExp> {
    const card = getValidationConfigFromCardNo(rawValue);
    if (card) {
      return card.mask;
    }
    return [/\d/];
  }

  getCardNumberControl(): AbstractControl | null {
    return this.paymentForm && this.paymentForm.get("cardnumber");
  }
  IntializePaymentForm() {
    this.paymentForm = this.formBuilder.group({      
      cardnumber: [
        "",
        [Validators.required, Validators.minLength(12), luhnValidator()],
      ],
      expiryMonth: ["", Validators.required],
      expiryYear: ["", Validators.required],
      zipCode: ["", Validators.required],
      ccv: ["", Validators.required],
      name: ["", Validators.required]    
    });

    this.paymentmodel.cardYear = "null";
    this.paymentmodel.cardMonth = "null";
  }
  get f() {
    return this.paymentForm.controls;
  }
  SaveCardDetails(){    
    
    this.isSubmitted= true;

    if(this.paymentForm.valid){
      this.cardType = this.getCardType(this.paymentmodel.cardNumber)
      this.cardValidate = this.validateCCcard(this.paymentmodel.cardMonth, this.paymentmodel.cardYear)
      if(this.cardValidate)
         this.cardDetailsValidate = true;
    }
    else
      this.cardDetailsValidate = false;
   

    console.log("Hello",this.paymentmodel, this.cardType,this.cardValidate)
   
  }

  ClearCardDetails(){
    this.paymentmodel = <IPaymentModel>{};
    this.paymentForm.reset();
  }
  
  validateCCcard(month, year) {
    debugger;
    let ptDatePattern = "^((0[1-9])|(1[0-2]))/([0-9]{4})$";
    let datevalue = month + "/" + year;
    if (datevalue.match(ptDatePattern)) return true;
    else {
      let todayDate = new Date();
     
      let controlDate = new Date(year, month - 1, 1, 23, 59, 59);
      let dateCompare = new Date(
        todayDate.getFullYear(),
        todayDate.getMonth(),
        1,
        0,
        0,
        0
      );
      
      if (dateCompare > controlDate) {
        return true;
      }
    }

    return false;
  }

  getCardType(cur_val) {
   
    if(cur_val != null && cur_val != undefined && cur_val != ""){
   
      var jcb_regex = new RegExp("^(?:2131|1800|35)[0-9]{0,}$"); 
    
      var amex_regex = new RegExp("^3[47][0-9]{0,}$"); //34, 37
    
      var diners_regex = new RegExp("^3(?:0[0-59]{1}|[689])[0-9]{0,}$"); 
     
      var visa_regex = new RegExp("^4[0-9]{0,}$"); //4
      
      var mastercard_regex = new RegExp(
        "^(5[1-5]|222[1-9]|22[3-9]|2[3-6]|27[01]|2720)[0-9]{0,}$"
      ); 
      var maestro_regex = new RegExp("^(5[06789]|6)[0-9]{0,}$"); 
      
      var discover_regex = new RegExp(
        "^(6011|65|64[4-9]|62212[6-9]|6221[3-9]|622[2-8]|6229[01]|62292[0-5])[0-9]{0,}$"
      );
      

      
      cur_val = cur_val.replace(/\D/g, "");

      
      var sel_brand = "unknown";
      if (cur_val.match(jcb_regex)) {
        sel_brand = "JCB";
      } else if (cur_val.match(amex_regex)) {
        sel_brand = "Amex";
      } else if (cur_val.match(diners_regex)) {
        sel_brand = "Diners_club";
      } else if (cur_val.match(visa_regex)) {
        sel_brand = "Visa";
      } else if (cur_val.match(mastercard_regex)) {
        sel_brand = "Mastercard";
      } else if (cur_val.match(discover_regex)) {
        sel_brand = "Discover";
      } else if (cur_val.match(maestro_regex)) {
        if (cur_val[0] == "5") {
          
          sel_brand = "MasterCard";
        } else {
          sel_brand = "Maestro"; 
        }
      }

      return sel_brand;
    }
  }
}
